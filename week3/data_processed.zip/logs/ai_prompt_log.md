# AI use log — Week 3, GSE87487

Kept because the Week 3 slides require it: "Prompts and accepted suggestions
belong in logs/ — part of provenance." Tool: Claude (Anthropic), 2026-09-13.

## Guardrails applied (Week 3, section 4.1)

1. **Verify every claim.** No accession, file name, size or statistic entered
   the submission from the model's prior knowledge. Each was read from the
   primary record (GEO Series page, GEO FTP, PubMed) or computed from the
   downloaded file.
2. **Never paste data blindly.** The script was read before running, and it
   fails loudly: `stopifnot()` guards the ID mapping, the dimensions, the
   column order and the integer check.
3. **Log the conversation.** This file.

## Sequence

| # | Stage | Asked | Returned | Decision |
|---|---|---|---|---|
| 1 | Dataset verification | Confirm study identity and every figure quoted in the assignment sheet | Opened GEO Series page, FTP directory, PubMed | **Accepted.** 20 samples, pre/post design, 3.7 MB counts file, SRP090633 all confirmed. The "nature microbiology paper" reference in the assignment did NOT check out — GSE87487 is published in *JCI Insight*, not a microbiome study. Flagged in the submission rather than papered over. |
| 2 | Design reconstruction | Sample table: patient, IRI status, stage per GSM | 20-row table | **Accepted after checking** against `metadata/sample_table.csv` from my own run — all 20 rows agree. |
| 3 | Script drafting | Fetch / clean / QC / DE script for this design | `GSE87487_week3.R` | **Accepted with changes.** Reviewed before running. |
| 4 | Bug — rank deficiency | — | Draft used `~ iri + iri:ind.n + iri:stage` | **Rejected, fixed.** Unbalanced 4-vs-6 design makes the matrix rank-deficient; R stopped with "the model matrix is not full rank". Replaced with a hand-built model matrix, all-zero and dependent columns dropped, passed via `full=`. |
| 5 | Bug — gz reading | — | `read.delim(cnt_file)` | **Fixed** to `read.delim(gzfile(cnt_file))`. |
| 6 | Draft analysis | — | Agent independently recomputed filter, QC and PCA from the downloaded matrix using log2-CPM, to check the script's logic before it ran | **Superseded by my run.** Where they disagree the run wins: PC1 variance 31.7% → **39%** (VST); IRI effect on PC1 p = 0.030 → **p = 0.171, not significant**. The submission reports the VST result. |
| 7 | Interpretation | Can gene symbols be added to the DE table? | Declined without an annotation package and a stated genome build | **Accepted.** No gene symbols are asserted anywhere in the submission; IDs stay as versioned Ensembl. |

## Cross-checks that passed

- Filtered gene count: agent's independent calculation **14,414**; my DESeq2 run
  **14,414 rows** in `DE_post_vs_pre.csv`.
- Library sizes: agent 7,059,456 – 10,610,420; my run, same.
- Sample-to-group mapping: agent's table vs `sample_table.csv`, 20/20 identical.

## What the AI did not do

It did not run the analysis. Every figure and every number in Part E of the
submission is the output of `GSE87487_week3.R` executed locally in
R 4.6.1 on Windows 11 (see `logs/session_info.txt`).
