# =====================================================================
# Week 3 homework — fetch, clean and document GSE87487
# Bioinformatics: From Multi-Omics Data to Discovery
# Dataset : GSE87487 (Sosa et al., JCI Insight 2016;1(20):e89679)
# Author  : Zhouhanyi (SUAT)
# NOTE    : Drafted with AI assistance (Claude). Every accession,
#           file name and number below was verified against the live
#           GEO / FTP record before being written down.
# =====================================================================

## ---- 00  project skeleton ------------------------------------------
dir.create("data_raw",       showWarnings = FALSE)
dir.create("data_processed", showWarnings = FALSE)
dir.create("metadata",       showWarnings = FALSE)
dir.create("figures",        showWarnings = FALSE)
dir.create("logs",           showWarnings = FALSE)

library(GEOquery)
library(DESeq2)
library(ggplot2)

## ---- 01  fetch -------------------------------------------------------
gse  <- getGEO("GSE87487", GSEMatrix = TRUE)
eset <- gse[[1]]
meta <- pData(eset)

# raw counts live in the supplementary file, NOT in the series matrix.
# Download only if it is not already on disk -- so re-running the script
# (or dropping the file in by hand) never re-fetches 3.7 MB from NCBI.
cnt_file <- file.path("data_raw", "GSE87487",
                      "GSE87487_counts.20samples.txt.gz")
if (!file.exists(cnt_file)) {
  getGEOSuppFiles("GSE87487", baseDir = "data_raw")
}
stopifnot(file.exists(cnt_file))
cat("counts file:", cnt_file, "-",
    round(file.size(cnt_file)/1e6, 2), "MB\n")   # expect 3.90 MB

## ---- 02  read counts -------------------------------------------------
# featureCounts output: 6 annotation columns before the 20 sample columns
raw <- read.delim(gzfile(cnt_file), check.names = FALSE)
stopifnot(ncol(raw) == 26)

gene_ann <- raw[, 1:6]                       # Geneid Chr Start End Strand Length
counts   <- as.matrix(raw[, 7:26])
rownames(counts) <- raw$Geneid               # Ensembl IDs, versioned
colnames(counts) <- sub("^Sample_", "", sub("\\.bam$", "", colnames(counts)))

## ---- 03  THE SILENT-MISALIGNMENT FIX ---------------------------------
# GEO sample titles and counts-file column names do NOT match literally:
#   GEO "Pt10Bx1"  vs counts "Pt10-Bx1"   (hyphen)
#   GEO "HBBX1"    vs counts "HBBx1"      (capitalisation)
# and the column ORDER differs from the GSM order. Never trust order.
norm_id <- function(x) toupper(gsub("-", "", x))

meta$sample_key <- norm_id(meta$title)
key_to_col <- setNames(colnames(counts), norm_id(colnames(counts)))

stopifnot(all(meta$sample_key %in% names(key_to_col)))   # fail loudly
counts <- counts[, key_to_col[meta$sample_key]]
colnames(counts) <- rownames(meta)                        # now GSM ids
stopifnot(identical(colnames(counts), rownames(meta)))

## ---- 04  build the design table --------------------------------------
meta$stage   <- factor(ifelse(grepl("post", meta$`transplant stage:ch1`),
                              "post", "pre"), levels = c("pre", "post"))
meta$iri     <- factor(ifelse(grepl("positive",
                              meta$`ischemia reperfusion injury (iri):ch1`),
                              "IRIpos", "IRIneg"), levels = c("IRIneg", "IRIpos"))
# patient = sample title with the trailing biopsy number removed
meta$patient <- factor(sub("[Bb][Xx][12]$", "", meta$title))

table(meta$iri, meta$stage)     # IRIneg 6/6 , IRIpos 4/4
length(levels(meta$patient))    # 10 patients, 2 biopsies each

## ---- 05  the five integrity checks -----------------------------------
stopifnot(!anyDuplicated(rownames(counts)))          # duplicate genes
stopifnot(sum(is.na(counts)) == 0)                   # missing values
stopifnot(ncol(counts) == nrow(meta))                # dimension match
stopifnot(identical(colnames(counts), rownames(meta)))  # order match
stopifnot(all(counts == floor(counts)), min(counts) >= 0)  # value range
cat("library sizes:", range(colSums(counts)), "\n")  # 7,059,456 - 10,610,420

## ---- 06  filter low-count genes --------------------------------------
# smallest group = 4 patients (IRI+), so require >=10 counts in >=4 samples
keep     <- rowSums(counts >= 10) >= 4
counts_f <- counts[keep, ]
cat(sum(keep), "of", nrow(counts), "genes retained\n")

## ---- 07  DESeq2 object — PAIRED design -------------------------------
# Samples are NOT independent: 2 biopsies per patient.
# patient absorbs the within-subject correlation; the interaction asks
# whether the pre->post change differs between IRI+ and IRI- recipients.
dds <- DESeqDataSetFromMatrix(
         countData = counts_f,
         colData   = meta[, c("patient", "iri", "stage")],
         design    = ~ patient + stage)
dds <- DESeq(dds)
res <- results(dds, name = "stage_post_vs_pre")
summary(res)
write.csv(as.data.frame(res[order(res$padj), ]),
          "data_processed/DE_post_vs_pre.csv")

## ---- 07b  IRI x stage interaction (exploratory, OPTIONAL) ------------
# `iri` cannot enter the model beside `patient`: every patient has exactly
# one IRI status, so the two are perfectly confounded. Use the DESeq2
# vignette's nested-individual trick: renumber patients WITHIN each IRI
# group, then ask whether the pre->post effect differs between groups.
#
# CAUTION: the groups are unbalanced (4 IRI+ vs 6 IRI-), so the naive
# formula ~ iri + iri:ind.n + iri:stage is RANK-DEFICIENT -- the
# iriIRIpos:ind.n5 and iriIRIpos:ind.n6 columns are all zeros and DESeq2
# stops with "the model matrix is not full rank". Build the matrix by
# hand, drop the empty columns, and pass it via `full=`.

meta$ind.n <- factor(ave(as.character(meta$patient), meta$iri,
                         FUN = function(x) match(x, unique(x))))

dds2 <- DESeqDataSetFromMatrix(
          countData = counts_f,
          colData   = meta[, c("iri", "ind.n", "stage")],
          design    = ~ 1)                       # placeholder, replaced below

mm <- model.matrix(~ iri + iri:ind.n + iri:stage,
                   data = as.data.frame(colData(dds2)))
mm <- mm[, colSums(abs(mm)) > 0, drop = FALSE]   # drop all-zero columns
qrm <- qr(mm)
mm  <- mm[, qrm$pivot[seq_len(qrm$rank)], drop = FALSE]  # drop dependencies

dds2 <- DESeq(dds2, full = mm, betaPrior = FALSE)

rn     <- resultsNames(dds2)
print(rn)
nm_pos <- grep("iriIRIpos.*stagepost", rn, value = TRUE)
nm_neg <- grep("iriIRIneg.*stagepost", rn, value = TRUE)
stopifnot(length(nm_pos) == 1, length(nm_neg) == 1)

# interaction = (post-pre in IRI+) - (post-pre in IRI-)
res_int <- results(dds2, contrast = list(nm_pos, nm_neg))
summary(res_int)
write.csv(as.data.frame(res_int[order(res_int$padj), ]),
          "data_processed/DE_interaction_IRI_by_stage.csv")
# NOTE: 4 vs 6 patients. Report as exploratory, not confirmatory.

## ---- 08  QC + PCA ----------------------------------------------------
vsd <- vst(dds, blind = TRUE)

p_group <- plotPCA(vsd, intgroup = "stage") + ggtitle("PCA — by transplant stage")
p_iri   <- plotPCA(vsd, intgroup = "iri")   + ggtitle("PCA — by IRI status")
p_pat   <- plotPCA(vsd, intgroup = "patient") + ggtitle("PCA — by patient (batch proxy)")
ggsave("figures/pca_stage.png",   p_group, width = 6, height = 5, dpi = 150)
ggsave("figures/pca_iri.png",     p_iri,   width = 6, height = 5, dpi = 150)
ggsave("figures/pca_patient.png", p_pat,   width = 6, height = 5, dpi = 150)

png("figures/qc_libsize.png", width = 900, height = 500)
barplot(colSums(counts) / 1e6, las = 2, ylab = "million reads",
        main = "Library size per sample")
dev.off()

png("figures/qc_boxplot.png", width = 900, height = 500)
boxplot(log2(counts_f + 1), las = 2, outline = FALSE,
        ylab = "log2(count + 1)", main = "Per-sample distribution")
dev.off()

## ---- 09  save + provenance -------------------------------------------
saveRDS(list(counts = counts_f, meta = meta, gene_ann = gene_ann),
        "data_processed/GSE87487_clean.rds")
write.csv(meta[, c("title", "patient", "iri", "stage")],
          "metadata/sample_table.csv")
writeLines(capture.output(sessionInfo()), "logs/session_info.txt")
